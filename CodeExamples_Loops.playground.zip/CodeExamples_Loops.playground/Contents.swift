import Cocoa

// Example: while loops

var product = 3

while (product <= 100)
{
    product *= 3
}

print(product)

// Example: repeat...while loop statement
var counter = 1

repeat {
    print("\(counter)  ")
    counter += 1
} while counter <= 10

print()
